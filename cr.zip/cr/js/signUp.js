var fname,lname,college,email,contact,chkbox,whyca,exp;
$(document).ready(function(){
	var tooltipFname,tooltipLname,tooltipCollege,tooltipEmail,tooltipContact,tooltipWhy;
	fname=0;
	lname=1;
	college=0;
	email=0;
	contact=0;
	whyca=0;
	chkbox=0;
	exp=1
	/*$('#fnameimg').on('click',function(){
		$(this).trigger('mouseover');
		$(this).trigger('mouseenter');
		$(this).trigger('hover');
	});*/
	$('input').keypress(function(e){
		if(e.which==32)
			return false;
	});
	var regExpcontact = /[0-9]/;
	  $('[name="contact"]').on('keydown keyup blur focus', function(e) {
	    var value =e.key;
	    /*var ascii=value.charCodeAt(0);
	    $('textarea').append(ascii);
	    $('textarea').append(value);
	    console.log(e);*/
	    // Only numbers
	    if (!regExpcontact.test(value)
	      && e.which != 8   // backspace
	      && e.which != 46  // delete
	      && (e.which < 37  // arrow keys
	        || e.which > 40)) {
	          e.preventDefault();
	          return false;
	    }
	  });
	  $('[name="contact"]').on('keypress', function(e) {
		  if($('[name="contact"]').val().length >9){
		    	e.preventDefault();
		    }
	  });
	
	  var regExpFname = /[a-zA-Z]/;
	  $('[name="fname"]').on('keydown keyup blur focus', function(e) {
	    var value =e.key;
	    /*var ascii=value.charCodeAt(0);
	    $('textarea').append(ascii);
	    $('textarea').append(value);
	    console.log(e);*/
	    // Only numbers
	    if (!regExpFname.test(value)
	      && e.which != 8   // backspace
	      && e.which != 46  // delete
	      && (e.which < 37  // arrow keys
	        || e.which > 40)) {
	          e.preventDefault();
	          return false;
	    }
	  });
	  
	  $('[name="fname"]').on('keypress', function(e) {
		  if($('[name="fname"]').val().length >39){
		    	e.preventDefault();
		    }
	  });
	  
	  var regExpCollege = /[a-zA-Z]/;
	  $('[name="college"]').on('keydown keyup blur focus', function(e) {
	    var value =e.key;
	    /*var ascii=value.charCodeAt(0);
	    $('textarea').append(ascii);
	    $('textarea').append(value);
	    console.log(e);*/
	    // Only numbers
	    if (!regExpCollege.test(value)
	      && e.which != 8   // backspace
	      && e.which != 46  // delete
	      && (e.which < 37  // arrow keys
	        || e.which > 40)) {
	          e.preventDefault();
	          return false;
	    }
	  });
	  
	  $('[name="college"]').on('keypress', function(e) {
		  if($('[name="fname"]').val().length >80){
		    	e.preventDefault();
		    }
	  });

	  var regExpLname = /[a-zA-Z]/;
	  $('[name="lname"]').on('keydown keyup blur focus', function(e) {

	    var value =e.key;
	    /*var ascii=value.charCodeAt(0);
	    $('textarea').append(ascii);
	    $('textarea').append(value);
	    console.log(e);*/
	    // Only numbers
	    if (!regExpLname.test(value)
	      && e.which != 8   // backspace
	      && e.which != 46  // delete
	      && (e.which < 37  // arrow keys
	        || e.which > 40)) {
	          e.preventDefault();
	          return false;
	      }
	  });
	  
	  $('[name="lname"]').on('keypress', function(e) {
		  if($('[name="lname"]').val().length >39){
		    	e.preventDefault();
		    }
	  });
	  // To allow only alphanumeric
	  var regExpWhy = /^[a-zA-Z0-9]+$/;
	  $('[name="whyca"]').on('keydown keyup blur focus', function(e) {
	    var value =e.key;
	    /*var ascii=value.charCodeAt(0);
	    $('textarea').append(ascii);
	    $('textarea').append(value);
	    console.log(e);*/
	    // Only numbers
	    if (!regExpWhy.test(value)
	      && e.which != 8   // backspace
	      && e.which != 32   // space
	      && e.which != 46  // delete
	      && (e.which < 37  // arrow keys
	        || e.which > 40)) {
	          e.preventDefault();
	          return false;
	    }
	  });
	  var regExpWhy2 = /^[^\s]([ ]{2,})[^\s]/;
	  $('[name="whyca2"]').on('keydown keyup blur focus', function(e) {
	    var value =e.key;
	    /*var ascii=value.charCodeAt(0);
	    $('textarea').append(ascii);
	    $('textarea').append(value);
	    console.log(e);*/
	    // Only numbers
	    if (!regExpWhy2.test(value)
	      && e.which != 8   // backspace
	      && e.which != 32   // space
	      && e.which != 46  // delete
	      && (e.which < 37  // arrow keys
	        || e.which > 40)) {
	          e.preventDefault();
	          return false;
	    }
	  });
	
	  $('input').on('keyup keydown keypress', function() {
		  if($(this).val().length==0){
			  var displayTooltip = "Please fill out this field";
			  var name = $(this).attr("name");
			  $(this).attr('title', displayTooltip);
			  if(name=="fname")
				  fname=0;
			  else if(name=="lname")
				  lname=0;
			  else if(name=="college")
				  lname=0;
			  else if(name=="contact")
				  contact=0;
			  else if(name=="email")
				  email=0;
			  $('#'+name+'img').attr("src","img/wrong.png");
			  $('#'+name+'img').prop("alt", "wrong");
			  $('#'+name+'img').attr("hidden",true);
			  $('#'+name+'img').attr('title', displayTooltip);
		  }
	  });
	  $('[name="whyca"]').on('keyup keydown keypress', function() {
		  if($(this).val().length==0){
			  var displayTooltip = "Please fill out this field";
			  var name = $(this).attr("name");
			  $(this).attr('title', displayTooltip);
			  if(name=="whyca")
				  whyca=0;
			  $('#'+name+'img').attr("src","img/wrong.png");
			  $('#'+name+'img').prop("alt", "wrong");
			  $('#'+name+'img').attr("hidden",true);
			  $('#'+name+'img').attr('title', displayTooltip);
		  }
	  });
	  setInterval(checkbox,0);
	  function checkbox(){
		  if($('[name="chkbox"]').is(":checked")){
			  chkbox=1;
		  }
		  else{
			  chkbox=0;
		  }
	  }
	  $('[name="fname"]').on('focus blur mouseleave',function(){
		  if($('[name="fname"]').val().length > 1){//$(this).blockUI({ message: '<h1><img src="img/wrong.png" /> Redirecting to email verification window in 3 seconds</h1>' });
			  fname=1;
			  tooltipFname="Accepted";
			  $('#fnameimg').attr("src","img/tick.png");
			  $('#fnameimg').prop("alt", "tick");
			  $('#fnameimg').attr("hidden",false);
		  }
		else{
			fname=0;
			tooltipFname="Please fill out this field";
			$('#fnameimg').attr("src","img/wrong.png");
			$('#fnameimg').prop("alt", "wrong");
			$('#fnameimg').attr("hidden",true);
		}
		  $('[name="fname"]').attr('title', tooltipFname);
		  $('#fnameimg').attr('title', tooltipFname);
	  });
	  $('[name="lname"]').on('focus blur mouseleave',function(){
		  if($('[name="lname"]').val().length > 1){
				lname=1;
				tooltipLname="Accepted";
				$('#lnameimg').attr("src","img/tick.png");
				$('#lnameimg').prop("alt", "tick");
				$('#lnameimg').attr("hidden",false);
			}
			else{
				lname=0;
				tooltipLname="Please fill out this field";
				$('#lnameimg').attr("src","img/wrong.png");
				$('#lnameimg').prop("alt", "wrong");
				$('#lnameimg').attr("hidden",true);
			}
		  $('[name="lname"]').attr('title', tooltipLname);
		  $('#lnameimg').attr('title', tooltipLname);	
	  });
	  $('[name="college"]').on('focus blur mouseleave',function(){
		  if($('[name="college"]').val().length > 4){
				college=1;
				tooltipCollege="Accepted";
				$('#collegeimg').attr("src","img/tick.png");
				$('#collegeimg').prop("alt", "tick");
				$('#collegeimg').attr("hidden",false);
			}
			else if($('[name="college"]').val().length > 0){
				college=0;
				tooltipCollege="Not a College name";
				$('#collegeimg').attr("src","img/wrong.png");
				$('#collegeimg').prop("alt", "wrong");
				$('#collegeimg').attr("hidden",false);
			}
			else{
				college=0;
				tooltipCollege="Please fill out this field";
				$('#collegeimg').attr("src","img/wrong.png");
				$('#collegeimg').prop("alt", "wrong");
				$('#collegeimg').attr("hidden",true);
			}
		  $('[name="college"]').attr('title', tooltipCollege);
		  $('#collegeimg').attr('title', tooltipCollege);	
	  });
		$('[name="email"]').on('focus blur mouseleave',function(){
			var emailid=$('[name="email"]').val();
			var a=emailid.indexOf("@");
			var b=emailid.lastIndexOf(".");
			if(emailid.length>0){
				if(a<1 || (b-3)<=a){
					email=0;
					tooltipEmail = "The email id "+emailid+" is not even an email id";
					$('#emailimg').attr("src","img/wrong.png");
					$('#emailimg').prop("alt", "wrong");
					$('#emailimg').attr("hidden",false);
				}
			}
			else{
				email=0;
				tooltipEmail = "Please fill out this field";
				$('#emailimg').attr("src","img/wrong.png");
				$('#emailimg').prop("alt", "wrong");
				$('#emailimg').attr("hidden",true);
			}
			$('[name="email"]').attr('title', tooltipEmail);
				$('#emailimg').attr('title', tooltipEmail);
		});
		$('[name="contact"]').on('focus blur mouseleave',function(){
			var contactnumber=$('[name="contact"]').val();
			if(contactnumber.length>0){
				if(contactnumber.length<10){
					contact=0;
					tooltipcontact = "The contact number "+contactnumber+" is invalid. It should be a 10 digit number";
					$('#contactimg').attr("src","img/wrong.png");
					$('#contactimg').prop("alt", "wrong");
					$('#contactimg').attr("hidden",false);
				}
				else{
					contact=1;
					tooltipcontact = "Accepted";
					$('#contactimg').attr("src","img/tick.png");
					$('#contactimg').prop("alt", "tick");
					$('#contactimg').attr("hidden",false);
					/*$.ajax({
					type: 'POST',
					data:{
						contactnumber: contactnumber,
						action: 'validExistWorkingcontact'
					},
					url: 'Registration1',
					cache:false,
					success: function(result){
						if(result==3){
							contact=1;
							tooltipcontact = "Accepted";
							$('#contactimg').attr("src","img/tick.png");
							$('#contactimg').prop("alt", "tick");
							$('#contactimg').attr("hidden",false);
						}
						else if(result==2){
							contact=0;
							tooltipcontact = "The contact number "+contactnumber+" is not a valid contact number";
							$('#contactimg').attr("src","img/wrong.png");
							$('#contactimg').prop("alt", "wrong");
							$('#contactimg').attr("hidden",false);
						}
						else if(result==1){
							contact=0;
							$('#contactimg').attr("src","img/wrong.png");
							$('#contactimg').prop("alt", "wrong");
							$('#contactimg').attr("hidden",false);
							alert("The contact number "+contactnumber+" is not working/active");
						}
						else{
							contact=0;
							tooltipcontact = "The contact number "+contactnumber+" is already associated with another account";
							$('#contactimg').attr("src","img/wrong.png");
							$('#contactimg').prop("alt", "wrong");
							$('#contactimg').attr("hidden",false);
						}
						$('[name="contact"]').attr('title', tooltipcontact);
						$('#contactimg').attr('title', tooltipcontact);
					}
				});*/
				}
			}
			else{
				contact=0;
				tooltipcontact = "Please fill out this field";
				$('#contactimg').attr("src","img/wrong.png");
				$('#contactimg').prop("alt", "wrong");
				$('#contactimg').attr("hidden",true);
			}
			$('[name="contact"]').attr('title', tooltipcontact);
			$('#contactimg').attr('title', tooltipcontact);
		});
		/*$('[name="address"]').on('focus blur mouseleave',function(){
			$('[name="address"]').attr('title', tooltipAddress);
			$('#addressimg').attr('title', tooltipAddress);
		});*/
		$('[name="whyca"]').on('focus blur mouseleave',function(){
		    if($('[name="whyca"]').val().trim().length > 35){
				whyca=1;
				tooltipWhy="Accepted";
				$('#whycaimg').attr("src","img/tick.png");
				$('#whycaimg').prop("alt", "tick");
				$('#whycaimg').attr("hidden",false);
			}
			else if($('[name="whyca"]').val().length > 0){
				whyca=0;
				tooltipWhy="Minimum 10 words required";
				$('#whycaimg').attr("src","img/wrong.png");
				$('#whycaimg').prop("alt", "wrong");
				$('#whycaimg').attr("hidden",false);
			}
			else{
				whyca=0;
				tooltipWhy="Please fill out this field";
				$('#whycaimg').attr("src","img/wrong.png");
				$('#whycaimg').prop("alt", "wrong");
				$('#whycaimg').attr("hidden",true);
			}
		  $('[name="whyca"]').attr('title', tooltipWhy);
		  $('#whycaimg').attr('title', tooltipWhy);	
	    });
	setInterval(Check, 0);
	function Check(){
		if(fname==1 && lname==1 && college==1 && email==1 && contact==1 && whyca==1 && exp==1 && chkbox==1){
			$('[name="btnREGISTER"]').addClass("grow");
			$('[name="btnREGISTER"]')[0].disabled=false;
		}
		else if(fname==0 || lname==0 || college==0 || email==0 || contact==0 || whyca==0 || exp==0 || chkbox==0){
			$('[name="btnREGISTER"]').removeClass("grow");
			$('[name="btnREGISTER"]')[0].disabled=true;
		}
	}
	function reset(){console.log("RESET clicked");
		fname=0;lname=1;contact=0;email=0;whyca=0;exp=1;college=0;chkbox=0;
		$('input[type=text],textarea').val("");
		var idarray=['#fname','#lname','#contact','#college','#email','#whyca'];
		for(i=0;i<idarray.length;i++){
			var tooltip = "Please fill out this field";
			$(idarray[i]+'img').attr("src","img/wrong.png");
			$(idarray[i]+'img').prop("alt", "wrong");
			$(idarray[i]+'img').attr("hidden",true);
			$(idarray[i]).attr('title', tooltip);
			$(idarray[i]+'img').attr('title', tooltip);
		}
		$('[name="chkbox"]').prop("checked", false);
	}
	$('[name="btnREGISTER"]').click(function(){
		$.ajax ({
        url : "gsign/signin.php",
        method: "POST",
        dataType: "json",
        data: {fname:fname,lname:lname, email:email, contact:contact, college:college, whyca:whyca, anyexp:anyexp},
        success: function(result) {
          alert(result);
        },
        error: function(error) {
          alert(error);
        }
      });
	});
});