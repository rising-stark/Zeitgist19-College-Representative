<?php
echo json_encode(array("result" => "hello123"));
?>